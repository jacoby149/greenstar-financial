export default [
  {
    FontAwesome: require('@expo/vector-icons/src/vendor/react-native-vector-icons/Fonts/FontAwesome.ttf'),
  },
  {
    Ionicons: require('@expo/vector-icons/src/vendor/react-native-vector-icons/Fonts/Ionicons.ttf'),
  },
  {
    Entypo: require('@expo/vector-icons/src/vendor/react-native-vector-icons/Fonts/Entypo.ttf'),
  },
  {
    SimpleLineIcons: require('@expo/vector-icons/src/vendor/react-native-vector-icons/Fonts/SimpleLineIcons.ttf'),
  },
  {
    MaterialIcons: require('@expo/vector-icons/src/vendor/react-native-vector-icons/Fonts/MaterialIcons.ttf'),
  },
  {
    MaterialCommunityIcons: require('@expo/vector-icons/src/vendor/react-native-vector-icons/Fonts/MaterialCommunityIcons.ttf'),
  },
];
