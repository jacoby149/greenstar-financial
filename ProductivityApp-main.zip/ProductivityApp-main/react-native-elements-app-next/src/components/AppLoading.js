export { AppLoading as default } from 'expo';
