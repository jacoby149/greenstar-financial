export { LinearGradient } from 'expo-linear-gradient';
