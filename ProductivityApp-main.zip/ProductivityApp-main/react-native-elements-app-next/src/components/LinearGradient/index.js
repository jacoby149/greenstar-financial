export { LinearGradient } from './LinearGradient';
