export const LinearGradient = undefined;
