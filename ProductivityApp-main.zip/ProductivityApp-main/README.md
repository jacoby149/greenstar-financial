# Productivity App

### Decisions

| Decision             | Choice              | Description / Reason                                      |
| -------------------- | ------------------- | --------------------------------------------------------- |
| Project Management   | Asana               | https://app.asana.com/0/1197215776322641/1197217875200884 |
| Platform             | NodeJS, ReactNative | Because its popular                                       |
| App Design Framework | Expo                | Makes cross platform design and testing easy.             |

### Getting Started

Getting Started With Expo : 

```
npm install -g expo-cli
```

Getting Started Tutorial : https://docs.expo.io/tutorial/planning/?redirected