import React from 'react'
import List from './List.js'
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native'

const App = () => {
  const [id, setId] = React.useState(4)
  const [nameList, setNameList] = React.useState([
        {
          id: 0,
          name: 'Ben',
        },
        {
          id: 1,
          name: 'Susan',
        },
        {
          id: 2,
          name: 'Robert',
        },
        {
          id: 3,
          name: 'Mary',
        },
    ]);
  let addNameAsync = async () => {
    setNameList([{id: id, name: `kevin_${id}`}].concat(nameList));
    setId(id+1);
  }
   return (
     <View style={styles.container}>
      <List state={nameList} />
      <TouchableOpacity onPress={addNameAsync} >
          <Text style = {styles.buttonText}>
            Press to add a name
          </Text>
      </TouchableOpacity>
     </View>
   )
}
export default App

const styles = StyleSheet.create ({
  container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
  },
  buttonText: {
    fontSize: 20,
    color: '#aaa',
  },
})
